package com.example.tankwar;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

import java.util.LinkedList;

public class load_games
{
    load_games(LinkedList list)
    {
        String[]images ={"4.png" ,"5.png"};
        Pane pane = new Pane();
        Image menu_image = new Image(getClass().getResourceAsStream("12.png"));
        ImageView imageview = new ImageView(menu_image);
        pane.getChildren().add(imageview);
        Scene scene = new Scene(pane);
        HelloApplication.set_scene(scene);

        Button back = new Button("BACK");
        back.setTranslateX(80);
        back.setTranslateY(50);
        back.setMaxHeight(50);
        back.setMinHeight(50);
        back.setScaleX(2);
        back.setScaleY(2);
        back.setOpacity(0);
        back.setOnAction(e->{
            new welcome_class();
        });
        pane.getChildren().add(back);

        int size = list.size();
        int o=-1;
        for(int i=size-1;i>0;i--)
        {
            o++;
            if (i==size-7){break;}
            Button temp = new Button("Game "+(i+1));
            String data = (String)list.get(i);
            String[] temp2 = data.split(",", 0);
            int h1 = Integer.parseInt(temp2[0]);
            int h2 = Integer.parseInt(temp2[1]);
            int x1 = Integer.parseInt(temp2[2]);
            int x2 = Integer.parseInt(temp2[3]);
            int tank1 = Integer.parseInt(temp2[4]);
            int tank2 = Integer.parseInt(temp2[5]);
            temp.setOnAction(e->{
                fight fightobj = new fight( h1,h2,x1,x2,tank1,tank2);
            });
            pane.getChildren().add(temp);
            temp.setTranslateX(424);
            temp.setTranslateY(190+(o)*80);
            temp.setMaxWidth(410);
            temp.setMinWidth(410);
            temp.setScaleY(3.1);
            temp.setScaleX(3);

        }
    }
}











