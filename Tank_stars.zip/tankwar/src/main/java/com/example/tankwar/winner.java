package com.example.tankwar;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

public class winner
{
    void end(int i)
    {
        Pane pane = new Pane();
        Image menu_image = new Image(getClass().getResourceAsStream("win.jpeg"));
        ImageView imageview = new ImageView(menu_image);
        Text win = new Text("Player "+i+" Won");
        pane.getChildren().addAll(imageview,win);
        win.setTranslateX(270);
        win.setTranslateY(290);
        win.setFill(Color.WHITE);
        Scene scene = new Scene(pane);
        HelloApplication.set_scene(scene);
        Button retry = new Button("Play again");
        retry.setTranslateX(270);
        retry.setTranslateY(330);
        pane.getChildren().add(retry);
        retry.setOnAction(e->{
            new welcome_class();
        });
    }

}
