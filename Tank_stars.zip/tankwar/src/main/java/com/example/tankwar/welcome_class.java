package com.example.tankwar;

import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.util.LinkedList;

public class welcome_class
{
    welcome_class() {
        Pane pane = new Pane();
        Image menu_image = new Image(getClass().getResourceAsStream("3b.PNG"));
        ImageView imageview = new ImageView(menu_image);
        pane.getChildren().add(imageview);
        setup(pane);
        Scene scene = new Scene(pane);
        HelloApplication.set_scene(scene);

    }

    public void setup(Pane pane)
    {
        Button new_game = new Button("NEW GAME");
        Button load_game = new Button("LOAD GAME");
        Button exit = new Button("EXIT");
        new_game.setOpacity(0);
        load_game.setOpacity(0);
        exit.setOpacity(0);
        pane.getChildren().addAll(new_game,load_game,exit);

        new_game.setScaleX(4.2);
        new_game.setScaleY(7);
        new_game.setTranslateX(1015);
        new_game.setTranslateY(100);
        new_game.setOnAction(e->start_new_game(e));

        load_game.setScaleX(4);
        load_game.setScaleY(7);
        load_game.setTranslateX(1010);
        load_game.setTranslateY(330);
        load_game.setOnAction(e->loaddata(e));


        exit.setScaleX(8);
        exit.setScaleY(7);
        exit.setTranslateX(1035);
        exit.setTranslateY(552);
        exit.setOnAction(e->{
            HelloApplication.shut_down();
        });

    }

    private void loaddata(ActionEvent e) {
        savedata saveobject = new savedata();
        LinkedList temp = saveobject.getdata();
        if (temp.size()==0)
        {
            System.out.println("NO game saved");
        }
        else {
            load_games loadGames = new load_games(temp);
        }

    }

    private void start_new_game(ActionEvent e) {
        new_game newGame = new new_game();
    }


}

//80 330 550