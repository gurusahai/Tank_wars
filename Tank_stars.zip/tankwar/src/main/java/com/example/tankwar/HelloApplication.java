package com.example.tankwar;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application
{
    private static Stage stage;
    @Override
    public void start(Stage stage) throws IOException {
        this.stage = stage;
        welcome_class welcomeClass = new welcome_class();
        stage.setTitle("Tank war");
        stage.show();
    }

    public static void set_scene(Scene scene)
    {
        stage.setScene(scene);
    }
    public static void main(String[] args) {
        launch();
    }
    public static void shut_down(){
        stage.close();
    }

}
