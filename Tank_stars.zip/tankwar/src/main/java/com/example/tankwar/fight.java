package com.example.tankwar;

import java.io.File;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

public class fight
{
//    static Text health1 , health2;
    static Tank player1;
    static Tank player2;
    static Pane pane;
    int[] tanks;
    Scene scene;
    static ProgressBar pb1,pb2;
    fight(int tank1 , int tank2) {
        tanks = new int[]{tank1, tank2};
        pane = new Pane();
        Image menu_image = new Image(getClass().getResourceAsStream("bg.jpeg"));
        ImageView imageview = new ImageView(menu_image);
        pane.getChildren().add(imageview);
        scene = new Scene(pane);
        HelloApplication.set_scene(scene);
        player1 = new Tank(50, 550, 45, tank1);
        player2 = new Tank(1100, 550, 180, tank2);
        set_ui(scene);
    }
    fight(int h1 ,int h2 ,int x1 ,int x2 ,int tank1 ,int tank2){
        tanks = new int[]{tank1, tank2};
        pane = new Pane();
        Image menu_image = new Image(getClass().getResourceAsStream("bg.jpeg"));
        ImageView imageview = new ImageView(menu_image);
        pane.getChildren().add(imageview);
        scene = new Scene(pane);
        HelloApplication.set_scene(scene);
        player1 = new Tank(x1, 550, 45,h1,tank1);
        player2 = new Tank(x2, 550, 180,h2,tank2);
        set_ui(scene);
    }
    private void set_ui(Scene scene){
        pb1 = new ProgressBar();
        pb1.setTranslateX(80);
        pb1.setTranslateY(720);
        pb1.setScaleX(2);
        pb1.setScaleY(2);
        pb1.setProgress(player1.getHealth()/100.0);

        pb2 = new ProgressBar();
        pb2.setTranslateX(1210);
        pb2.setTranslateY(720);
        pb2.setScaleX(2);
        pb2.setScaleY(2);
        pb2.setProgress(player2.getHealth()/100.0);
        pane.getChildren().addAll(pb1,pb2);

        Button pause = new Button("Pause");
        pause.setTranslateX(1250);
        pause.setTranslateY(50);
        pause.setScaleX(2);
        pause.setScaleY(2);
        pause.setOnKeyPressed(e-> {
            try {
                setkeyboard(e);
            } catch (InterruptedException ex) {
                throw new RuntimeException(ex);
            }
        });
        pause.setOnKeyReleased(e->stop_key(e));
        pause.setOnAction(e->pause());

        scene.setOnKeyPressed(e -> {
            try {
                setkeyboard(e);
            } catch (InterruptedException ex) {
                throw new RuntimeException(ex);
            }
        });
        scene.setOnKeyReleased(e->stop_key(e));
//        health1 = new Text(player1.getHealth()+"");
//        health1.setScaleX(3);
//        health1.setScaleY(3);
//        health1.setTranslateX(100);
//        health1.setTranslateY(120);
//        health2 = new Text(player2.getHealth()+"");
//        health2.setScaleX(3);
//        health2.setScaleY(3);
//        health2.setTranslateX(1300);
//        health2.setTranslateY(120);
//        pane.getChildren().addAll(health1,health2,pause);
    }
    public static void sethealths(){
        int temp1 = player1.getHealth();
        int temp2 = player2.getHealth();
        pb1.setProgress(temp1/100.0);
        pb2.setProgress(temp2/100.0);
        if(temp1<=0)
        {
            winner winner = new winner();
            winner.end(2);
        }
        else if (temp2<=0)
        {
            winner winner = new winner();
            winner.end(1);
        }
    }
    public static void blast(int tempx, int tempy) {
        int player1x = player1.getabsx()+50;
        int player1y = player1.getabsy();
        int player2x = player2.getabsx()+50;
        int player2y = player2.getabsy();
        int temp1 = player1x-tempx;
        int temp2 = player2x-tempx;
        double n = 150;
        if(Math.abs(temp2)<n){
            player2.reduce_health((int)((10.0/n)*(Math.abs(temp2))));
            player2.displace((int) (Math.signum(temp2)*  ( n-Math.abs(temp2))));
        }
        if(Math.abs(temp1)<n){
            player1.reduce_health((int)((10.0/n)*(Math.abs(temp1))));
            player1.displace((int) (Math.signum(temp1)*  ( n-Math.abs(temp1))));
        }
        System.out.println("player 1 health ->"+player1.getHealth()+"   "+temp1);
        System.out.println("player 2 health ->"+player2.getHealth()+"   "+temp2);
    }
    private void stop_key(KeyEvent e) {
        KeyCode key = e.getCode();
        if (key==KeyCode.A){
            player2.stop_x();
        }
        else if(key==KeyCode.D){
            player2.stop_x();
        }
        if(key==KeyCode.RIGHT){
            player1.stop_x();
        }
        else if(key==KeyCode.LEFT){
            player1.stop_x();
        }

    }
    private void setkeyboard(KeyEvent e) throws InterruptedException {
        KeyCode key = e.getCode();
        if (key==KeyCode.UP){
            player1.angleup();
        }
        else if(key==KeyCode.DOWN){
            player1.angledown();
        }
        else if(key==KeyCode.RIGHT){
            player1.move_x(false);
        }
        else if(key==KeyCode.LEFT){
            player1.move_x(true);
        }
        else if(key==KeyCode.L){
            try {
                player1.fire();
            } catch (InterruptedException ex) {
                throw new RuntimeException(ex);
            }
        }
        else if(key==KeyCode.A){
            player2.move_x(true);
        }
        else if(key==KeyCode.D){
            player2.move_x(false);
        }
        else if(key==KeyCode.S){
            player2.angleup();
        }
        else if(key==KeyCode.W){
            player2.angledown();
        }
        else if(key==KeyCode.V){
            player2.fire();
        }
        else if(key==KeyCode.ESCAPE){
            pause();
        }

    }
    private void pause() {
        Pane pane = new Pane();
        Image menu_image = new Image(getClass().getResourceAsStream("11.png"));
        ImageView imageview = new ImageView(menu_image);
        pane.getChildren().add(imageview);
        Scene pause_scene = new Scene(pane);
        HelloApplication.set_scene(pause_scene);

        Button resume = new Button("RESUME");
        resume.setTranslateX(190);
        resume.setTranslateY(540);
        resume.setScaleX(5.4);
        resume.setScaleY(6.5);
        resume.setOpacity(0);
        resume.setOnAction(e->{
            HelloApplication.set_scene(scene);
        });

        Button save = new Button("SAVE");
        save.setTranslateX(600);
        save.setTranslateY(540);
        save.setScaleX(7.2);
        save.setScaleY(6.5);
        save.setOpacity(0);
        save.setOnAction(e->save_game());


        Button exit = new Button("EXIT");
        exit.setTranslateX(1000);
        exit.setTranslateY(540);
        exit.setScaleX(8);
        exit.setScaleY(6.5);
        exit.setOpacity(0);
        exit.setOnAction(e->exit());

        pane.getChildren().addAll(save,resume,exit);
    }
    private void save_game(){
        savedata saveobject = new savedata();
        int h1 = player1.getHealth();
        int h2 = player2.getHealth();
        int x1 = player1.getabsx();
        int x2 = player1.getabsx();
        int tank1 = tanks[0];
        int tank2 = tanks[1];
        saveobject.savedata(h1,h2,x1,x2,tank1,tank2);
        exit();
    }
    private void exit()
    {
        welcome_class welcomeClass = new welcome_class();
    }


}

