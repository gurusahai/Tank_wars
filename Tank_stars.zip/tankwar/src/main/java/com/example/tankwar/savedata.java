package com.example.tankwar;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.Scanner;

public class savedata {

    File file;
    savedata() {
        try {
            System.out.println("hi im yash");
            file = new File("gamedata.txt");
            if (file.exists()) {
                System.out.println("Firl Exists");
            } else {
                PrintWriter writer = new PrintWriter("gamedata.txt");
                writer.close();
                file = new File("gamedata.txt");
            }
        }
        catch (Exception e)
        {
            System.out.println(e);
        }


    }

    public LinkedList<String> getdata() {
        try{
            LinkedList<String> temp = new LinkedList<String>();
            File file = new File("gamedata.txt");
            Scanner sc = new Scanner(file);
            while (sc.hasNextLine())
            {
                String t = sc.nextLine();
                temp.add(t);
            }
            return temp;
        }
        catch(Exception e){
            return new LinkedList<String>();
        }
    }

    public void savedata(int h1 ,int h2 ,int x1 ,int x2 ,int tank1 ,int tank2) {
        try {
            FileWriter fr = new FileWriter(file, true);
            fr.write( h1+","+h2+","+x1+","+x2+","+tank1+","+tank2+"\n");
            fr.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


}
