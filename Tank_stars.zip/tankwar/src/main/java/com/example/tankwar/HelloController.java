package com.example.tankwar;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

public class HelloController {
    @FXML
    private static Button b;
    public static void setup(Pane pane) {
        b = new Button("hello");
        b.setOnMouseClicked(e -> onHelloButtonClick());
        pane.getChildren().add(b);
    }

    @FXML
    protected static void onHelloButtonClick()
    {
        b.setText("Welcome to JavaFX Application!");
    }
}
