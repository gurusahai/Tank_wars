package com.example.tankwar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polygon;
import javafx.util.Duration;
import java.util.concurrent.atomic.AtomicInteger;

public class Tank
{
    private int health = 100;
    int displacement_value , displacement_speed;
    int x_speed,y_speed;
    boolean x_moving=false,y_moving=false ,pos;
    int angle;
//    Polygon tank;
    ImageView tank;
    Timeline movement_timer , displacement_timer;
    int dis = 0;
    Tank(int x, int y,int angle,int tank1){
        this.angle=angle;
        settank(x,y,tank1);
        settimer();
        fight.pane.getChildren().add(tank);
        x_speed = (int)(10 * Math.cos(Math.toRadians(angle)));
        y_speed = (int)(10 * Math.sin(Math.toRadians(angle)));
        set_displacement_timer();
    }
    Tank(int x, int y,int angle,int health,int tank1){
//        this.x=x;
//        this.y=y;
        this.health = health;
        this.angle=angle;
        settank(x,y,tank1);
        settimer();
        fight.pane.getChildren().add(tank);
        x_speed = (int)(10 * Math.cos(Math.toRadians(angle)));
        y_speed = (int)(10 * Math.sin(Math.toRadians(angle)));
        set_displacement_timer();
    }
    private void settank(int x,int y,int tank_index) {
        String[] images = {"t1.png","t2.png","t3.png"};
        Image  image = new Image(getClass().getResourceAsStream(images[tank_index]));
        tank = new ImageView(image);
        tank.setTranslateX(x);
        tank.setTranslateY(y);
    }
    private void settimer() {
        movement_timer = new Timeline(new KeyFrame(Duration.millis(30),e->{
            if((tank.getTranslateX()+x_speed>0)&(tank.getTranslateX()+x_speed<1250)) {
                tank.setTranslateX(tank.getTranslateX() + x_speed);
            }
        }));
        movement_timer.setCycleCount(Timeline.INDEFINITE);
    }
    public void angleup(){
        angle+=5;
    }
    public void angledown(){
        angle-=5;
    }
    public void fire() throws InterruptedException {
        bullet temp = new bullet((int)tank.getTranslateX(),(int)tank.getTranslateY(),angle);
        Circle bull = temp.getCircle();
        fight.pane.getChildren().add(bull);

    }
    public void move_x(boolean neg){
        System.out.println("1234");
        if (neg & x_speed>0){
            x_speed = -1*x_speed;
        }
        else if(!neg & x_speed<0){
            x_speed*=-1;
        }
        if (!x_moving) {
            movement_timer.play();
            x_moving = true;
        }
    }
    public void stop_x() {
        movement_timer.stop();
        x_moving = false;
    }
    public int getabsx(){
        int tempx = (int)(tank.getTranslateX());
        return tempx;
    }
    public int getabsy(){
        int tempy = (int)(tank.getTranslateY());
        return tempy;
    }
//    public void displace(int m){
//        System.out.println("  m == "+m);
//        int temp = 0;
//        System.out.println(m);
//        if ((x+m>0)&(x+m<1250))
//        {
////            tank.setTranslateX(x+=m);
//            temp = (x+=m);
//        }
//        else
//        {
//            if(x+m>1250)
//            {
////                tank.setTranslateX(x=1249-x);
//                temp = (x=1249-x);
//            }
//            else if(x+m<0)
//            {
////                tank.setTranslateX(x*-1+1);
//                temp = (x*-1+1);
//                x=1;
//            }
//        }
//        displacement_value = temp;
//        x=temp;
//        System.out.println("displacement value = "+displacement_value);
//        if(displacement_value-tank.getTranslateX()>0)
//        {
//            pos=true;
//        }
//        else {
//            pos=false;
//        }
//        int count = Math.abs((int)((temp - tank.getTranslateX())/5));
//        displacement_timer.setCycleCount(count);
//        displacement_timer.play();
//    }
    public void displace(int m){
        System.out.println("m value is -->>  "+m);
        displacement_value = m;
        if (displacement_value<0)
        {
            displacement_speed = -5;
        }
        else {
            displacement_speed = 5;
        }
        displacement_timer.play();
    }

    private void set_displacement_timer(){
        displacement_timer = new Timeline(new KeyFrame(Duration.millis(10),e->{
            System.out.println(tank.getTranslateX());
            int temp = (int)tank.getTranslateX()+displacement_speed;
            if((temp<0)||(temp>1250))
            {
                displacement_timer.stop();
            }
            else {
                tank.setTranslateX(temp);
                displacement_value = displacement_value + (-1)*displacement_speed;
                if((displacement_speed<0)&(displacement_value>=0))
                {
                    displacement_timer.stop();
                    System.out.println("here");
                }
                else if ((displacement_speed>0)&(displacement_value<=0)) {
                    displacement_timer.stop();
                    System.out.println("here  2");
                }
            }
            System.out.println(" displacement value ===>>>>> "+displacement_value+"    "+displacement_speed);

        }));
        displacement_timer.setCycleCount(Timeline.INDEFINITE);
    }

//    private void set_displacement_timer(){
//        displacement_timer = new Timeline(new KeyFrame(Duration.millis(30),e->{
//            if(pos)
//            {
//                if(displacement_value-tank.getTranslateX()<0)
//                {
//                    displacement_timer.stop();
//                }else {
//                    tank.setTranslateX(tank.getTranslateX()+5);
//                }
//            }
//            else
//            {
//                if(tank.getTranslateX()-displacement_value<0)
//                {
//                    displacement_timer.stop();
//                }
//                else{
//                    tank.setTranslateX(tank.getTranslateX()-5);
//                }
//            }
////            if (displacement_value>0)
////            {
////                tank.setTranslateX(tank.getTranslateX()-5);
////                displacement_value-=5;
////                x-=5;
////                System.out.println(displacement_value);
////            }
////            else {
////                displacement_timer.stop();
////            }
//        }));
//    }
    public void reduce_health(int x){
        health-=x;
        fight.sethealths();
    }
    public int getHealth(){
        return health;
    }


}

class bullet
{
    int x_vel,y_vel;
    Timeline timer;
    boolean moving = false;
    int x,y;
    int angle;
    Circle object;
    Timeline blast;

    bullet(int x ,int y ,int angle) throws InterruptedException {
        int velocity = 25;
        this.x=x;
        this.y=y+50;
        this.angle=angle;
        y_vel = (int)(velocity*Math.sin(Math.toRadians(angle)));
        x_vel = (int)(velocity*Math.cos(Math.toRadians(angle)));
//        System.out.println(x_vel+"   "+y_vel);
        object = new Circle(0,0,10);
        object.setFill(Color.RED);
        object.setTranslateX(x);
        object.setTranslateY(y);
        set_timer();
        triger();
    }

    public Circle getCircle(){
        return object;
    }

    private void set_timer() {
        AtomicInteger temp = new AtomicInteger(y_vel);
        timer = new Timeline(new KeyFrame(Duration.millis(30),e->{
//            System.out.println(x+"   "+temp);
            object.setTranslateX(x=(int)object.getTranslateX()+x_vel);
            object.setTranslateY(y=(int)object.getTranslateY()-y_vel);
            y_vel-=1;
            if(-1*y_vel>temp.get()+3){
                timer.stop();
                end_bullet();
            }
        }));
        timer.setCycleCount(Timeline.INDEFINITE);
    }

    private void triger()
    {
        if(!moving)
        {
            timer.play();
            moving = true;
        }

    }


    private void end_bullet() {
        AtomicInteger i= new AtomicInteger(0);
        int n=80;
        blast = new Timeline(new KeyFrame(Duration.millis(3),e->{
            i.set(i.get()+1);
//            System.out.println("i is ----->>>> "+i.get()+"        ,"+(1-i.get()*(1/n)));
            object.setRadius(10+ i.get() *2);
            object.setOpacity(1-i.get()*(1.0/(float)n));
            if(object.getRadius()>n){
                blast.stop();
                object.setOpacity(0);
                int tempy = (int)(object.getTranslateY()+object.getLayoutY());
                int tempx = (int)(object.getTranslateX()+object.getLayoutX());
                int tempx2 = (int)(object.getTranslateX()+object.getCenterX());
                int tempy2 = (int)(object.getTranslateY()+object.getCenterY());
//                System.out.println("########################");
//                System.out.println(tempx+"   "+tempy+"   ,   "+tempx2+"    "+tempy2 );
//                System.out.println("########################");
            }
        }));
        blast.setCycleCount(Timeline.INDEFINITE);
        blast.play();
        int tempx = (int)(object.getTranslateX()+object.getCenterX());
        int tempy = (int)(object.getTranslateY()+object.getCenterY());
        fight.blast(tempx,tempy);
    }

}


















