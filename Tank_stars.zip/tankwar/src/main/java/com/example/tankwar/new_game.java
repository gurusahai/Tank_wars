package com.example.tankwar;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

public class new_game
{

    int[] tanks = {0,0};

    new_game()
    {
        select_tank(0);
    }

    private void select_tank(int tank_index) {
        String[]images ={"4.png" ,"5.png"};
        Pane pane = new Pane();
        Image menu_image = new Image(getClass().getResourceAsStream(images[tank_index]));
        ImageView imageview = new ImageView(menu_image);
        pane.getChildren().add(imageview);
        Scene scene = new Scene(pane);
        HelloApplication.set_scene(scene);

        Button tank1 = new Button("TANK 1");
        Button tank2 = new Button("TANK 2");
        Button tank3 = new Button("TANK 3");
        pane.getChildren().addAll(tank1, tank2, tank3);

        tank1.setTranslateX(172);
        tank1.setTranslateY(630);
        tank1.setOnAction(e -> {
            tanks[tank_index] = 0;
            if(tank_index==0){
                select_tank(1);
            }
            else if(tank_index==1){
                start();
            }
        });

        tank2.setTranslateX(572);
        tank2.setTranslateY(630);
        tank2.setOnAction(e -> {
            tanks[tank_index] = 1;
            if(tank_index==0){
                select_tank(1);
            }
            else if(tank_index==1){
                start();
            }
        });

        tank3.setTranslateX(1010);
        tank3.setTranslateY(630);
        tank3.setOnAction(e -> {
            tanks[tank_index] = 2;
            if(tank_index==0){
                select_tank(1);
            }
            else if(tank_index==1){
                start();
            }
        });

        Button back = new Button("back");
        back.setTranslateX(70);
        back.setTranslateY(66);
        back.setScaleX(2.5);
        back.setScaleY(4);
        back.setOpacity(0);
        back.setOnAction(e->{
            select_tank(0);
        });
        if(tank_index==0){back.setDisable(true);back.setOpacity(0);}
        pane.getChildren().add(back);

    }

    private void start()
    {
        fight fight = new fight(tanks[0] ,tanks[1]);
    }

}












