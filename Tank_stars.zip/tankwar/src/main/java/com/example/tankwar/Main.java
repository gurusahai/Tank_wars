package com.example.tankwar;
	

import java.util.ArrayList;
import javafx.animation.Animation.Status;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;


public class Main extends Application
{
	
	
	static Pane root ;
	static Pane root2 ;
	static Scene scene;
	static HBox window;
	static Button b;
	static Rectangle boi;
	//static Text t;
	
	
	static Timeline timer1;
	static Timeline timer2;
	static Timeline timer3;
	static Timeline timer4;
	
	static boolean boolx = false;
	static boolean booly = false;
	
	
	static int range = 300;
	static int g = 3;
 	static int tempspeedy;
	static int xx = g*10;
	static boolean down = false;
	
	
	static int fps = 30;
	static int speedy = g*10;
	static int speedx = 15;
	static int windowheight = 700;
	
	
	
	static int pos = 1;
	static int pos2 = 0;
	static int y = 0;
	static int index=0;
	static int [] arr1 = {50,100,30,70,11,120,10}; 
	static int [] arr2 = {19,10,35,18,11,8,0}; 
	static int [] arr3 = {8,5,4,8,7,5,10}; 
	
	static ArrayList<Integer> heights = new ArrayList<Integer>();
	static ArrayList<evil> evils = new ArrayList<evil>();
	
	
	public static void main(String[] args)
	{
		launch(args);
	}
	
	public void start(Stage primaryStage) 
	{
		try 
		{
			
			root = new Pane();
			scene = new Scene(root,700,500);
			setup();
			primaryStage.setScene(scene);
			primaryStage.show();
			
			
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	}

	private void setup() 
	{
		
		
		window = setbox();

		root2 = new Pane();
		root.getChildren().add(root2);
		
		for(int i=0;i<8;i++)
		{	block.add();	}
		
//		for(int i=0;i<40;i++)
//		{
//			evil temp = new evil(i*600+arr1[index%arr1.length], i*500+200 +arr1[index%arr1.length]  ,100+arr2[index%arr1.length],arr3[index%arr1.length]);
//			Main.evils.add(temp);
//			index++;
//		}
		
		root.getChildren().add(window);
		setboi();
		timer4();
		timer3();
		timer2();
		timer1();
		setbutton();
		
//		t = new Text();
//		root.getChildren().add(t);
//		t.setTranslateX(100);
//		t.setTranslateY(100);
		
		timer4.play();
		
	}
	
	private HBox setbox()
	{
		HBox window = new HBox();
		window.setTranslateY(500-windowheight);
		window.setMaxHeight(windowheight);
		window.setMinHeight(windowheight);
		window .setAlignment(Pos.BOTTOM_CENTER);
		window.setStyle("-fx-background: #90EE91; -fx-border-color: #90EE90;");
		return window;
		
	}
		
	public static void setboi()
	{
		boi = new Rectangle(); 
		boi.setHeight(block.b_diff);
		boi.setWidth(block.b_diff+1);
		root.getChildren().add(boi);
		boi.setTranslateX(pos*block.width);
		//boi.setFill(Paint.valueOf(Color.BLUE.toString()));
//		int temp = (int)  (  (Rectangle)window.getChildren().get(x/block.width)).getHeight() ;
//		int temp2 = (int)(    window.getTranslateY()+( windowheight - temp ) - block.b_diff  );
	//	y = temp2;
		boi.setTranslateY(heights.get(pos)-block.b_diff);
		y = heights.get(pos)-block.b_diff;
		
	}
	
	private void setbutton() 
	{
		b = new Button();
		b.setTranslateX(-50);
		root.getChildren().add(b);
		b.setOnKeyPressed(e->pressed(e));
		b.setOnKeyReleased(e->released(e));
		
	}
	
	private void released(KeyEvent e) 
	{
		KeyCode key = e.getCode();
		if(boolx& key.equals(KeyCode.L))
		{
			timer1.pause();
			boolx = false;
			
		}
		if(boolx& key.equals(KeyCode.J))
		{
			timer2.pause();
			boolx = false;
			
		}
//		if(booly& key.equals(KeyCode.I))
//		{
////			timer3.pause();
////			booly = false;
////			
//		}
		
	}

	private void pressed(KeyEvent e) 
	{
		if(!timer3.getStatus().equals(Status.RUNNING))
		{
			booly = false;
		}
		
		KeyCode key = e.getCode();
		if(!boolx& key.equals(KeyCode.L))
		{
			boolx = true;
			timer1.play();
			
		}
		if(!boolx& key.equals(KeyCode.J))
		{
			boolx = true;
			timer2.play();
		}
		if(!booly& key.equals(KeyCode.I))
		{
			booly = true;
			timer3.play();
		}
		if(!boolx& key.equals(KeyCode.R))
		{
			Rectangle temp = new Rectangle();
			temp.setHeight(80);
			temp.setWidth(160);
			temp.setFill(Paint.valueOf(Color.RED.toString()));
			root2.getChildren().add(temp);
			TranslateTransition t = new TranslateTransition(Duration.millis(700));
			t.setNode(temp);
			t.setByX(400);
			t.setByX(200);
			t.play();
			t.setOnFinished(ev->
			{
				root2.getChildren().remove(temp);
			});
		}
		
	}

	private void  timer1()
	{
		timer1 = new Timeline(new KeyFrame(Duration.millis(fps),ev->
		{
			
			if(pos2<block.width-block.b_diff-speedx)
			{
//				window.setTranslateX(window.getTranslateX()-(speedx));
//				pos2+=speedx;
				movewindow(speedx);
			}
			else
			{
				int nextheight = heights.get(pos+1);
				if(y+block.b_diff<=nextheight)
				{
//					window.setTranslateX(window.getTranslateX()-speedx);
//					pos2+=speedx;
					movewindow(speedx);
				}
				else
				{
					int temp = block.width-block.b_diff-pos2;
//					window.setTranslateX(window.getTranslateX()-temp);
//					pos2+=temp;
					movewindow(temp);
				}
			}
			if(pos2>block.width)
			{
				pos++;
				block.add();
				pos2 = pos2%block.width;
				if(!booly)
				{
					xx=0;
					booly=true;
					timer3.play();					
				}
			}
		//	t.setText("x-> "+pos2+" y-> "+y);
			
		}));
		checkdown();
		timer1.setCycleCount(1000);
		
		
	}
	
	private void  timer2()
	{
		timer2 = new Timeline(new KeyFrame(Duration.millis(fps),ev->
		{
			
			if(pos2>=speedx)
			{
//				window.setTranslateX(window.getTranslateX()+(speedx));
//				pos2-=speedx;
				movewindow(-1*speedx);
			}
			else
			{
				int nextheight = heights.get(pos-1);
				if(y+block.b_diff<=nextheight)
				{
//					window.setTranslateX(window.getTranslateX()+speedx);
//					pos2-=speedx;
					movewindow(-1*speedx);
				}
				else
				{
					int temp = pos2;
//					window.setTranslateX(window.getTranslateX()+temp);
//					pos2-=temp;
					movewindow(-1*temp);
				}
			}
			if(pos2<0)
			{
				
				pos--;
				pos2 = (pos2+block.width)%block.width;
				
			}
			checkdown();
			//t.setText("x-> "+pos2+" y-> "+y);
		}));
		timer2.setCycleCount(1000);
		
		
	}
		
	private void  timer3()
	{
		tempspeedy = speedy;
		timer3 = new Timeline(new KeyFrame(Duration.millis(fps),ev->
		{
			if((xx>0)&(!down))
			{
				xx-=g;
				boi.setTranslateY(boi.getTranslateY()-(xx+1)*(tempspeedy/(g*10)));
				y-=(xx+1)*(tempspeedy/(g*10));
				//tempspeedy-=2;
			}
			else
			{
				down = true;
				xx+=g;
				int downheight =  heights.get(pos);
				
				int h2 = heights.get(pos+1);
				if((pos2>block.width-block.b_diff)&(h2<downheight))
				{
					downheight = h2;
				}
				
				if(downheight>y+block.b_diff+((xx+1)*(tempspeedy/(g*10))))
				{
					System.out.println("moving");
					boi.setTranslateY(boi.getTranslateY()+((xx+1)*(tempspeedy/(g*10))));
					y+=((xx+1)*(tempspeedy/(g*10)));
					//tempspeedy+=2;
				}
				else if(y+block.b_diff==downheight)
				{
					timer3.pause();
					xx=g*10;
					down = false;
					tempspeedy = speedy;
					booly = false;
					System.out.println("-------stopping--------");
				}
				else
				{
					System.out.println("setting");
					boi.setTranslateY(downheight-block.b_diff);
					y=downheight-block.b_diff;
					//tempspeedy+=2;
				}
				System.out.println("downheight = "+downheight);	
			}
		}));
		timer3.setCycleCount(1000);
		
		
	}
	
	private void  timer4()
	{
		timer4 = new Timeline(new KeyFrame(Duration.millis(fps*3),ev->
		{
			for(evil temp:evils)
			{
				if(temp.status)
				{
					moveevil(temp);
					Point2D cor = temp.rect.localToParent(0, 0);
					int translation = (int) cor.getX();
					if(translation-range<pos*block.width+pos2  ||  translation+range>pos*block.width+pos2 )
					{
						Rectangle r = temp.rect;
						if(!(pos2==0 || pos2==block.width-block.b_diff)&(pos*block.width+pos2>r.getTranslateX()-range)&(pos*block.width+pos2<r.getTranslateX()+range))
						{
							attack(temp);
						}
					}
					
				}
			}
		}
		));
		timer4.setCycleCount(1000);
	
	}
		
	
	
	private void attack(evil temp) 
	{
		int x0 = (int)temp.rect.getTranslateX();
		int y0 = temp.y;
		
		int x2 = 500;
		int y2 = 500;
		
		if(boolx)
		{
			
		}
		
			x2 = pos*block.width+pos2;
			y2 = y;
		
		
		Circle attackrect = new Circle(x0+temp.rect.getWidth()/2,y0+10,5);
		root2.getChildren().add(attackrect);
		TranslateTransition trans = new TranslateTransition(); 
		trans.setByX(x2-x0);
		trans.setByY(y2-y0+block.b_diff);
		trans.setDuration(Duration.millis(800));
		trans.setNode(attackrect);
		trans.play();
		trans.setOnFinished(e->
		{
			 attackrect.setCenterX(attackrect.getCenterX() + attackrect.getTranslateX());
			 attackrect.setTranslateX(0);
		//	if((pos*block.width+pos2>x0+temp.rect.getWidth()/2+trans.getByX()-5)&(pos*block.width+pos2<x0+temp.rect.getWidth()/2+trans.getByX()+5))
			//if(   (pos*block.width+pos2>attackrect.getCenterX()+attackrect.getTranslateX()+10)  &  ( pos*block.width+pos2<attackrect.getCenterX()+attackrect.getTranslateX() +10    )  )
			if((attackrect.getCenterX()+30>pos*block.width+pos2)&(pos*block.width+pos2>attackrect.getCenterX()-0))
			 {
				Pane p = new Pane();
				Text t = new Text(" you looser bruh.");
				t.setFont(Font.font(24));
				t.setTranslateX(100);
				t.setTranslateY(300);
				//t.setText("adhiraj looser");
				p.getChildren().add(t);
				scene.setRoot(p);
			}
			root2.getChildren().remove(attackrect);
			attackrect.setFill(Paint.valueOf(Color.RED.toString()));
			
		});
		
		
	}

	public static void moveevil(evil temp)
	{
		int x = (int)(temp.rect.getTranslateX());
		int move = (temp.speed);;
		if(temp.back)
		{
			move = (-1*temp.speed);
		}
		
		temp.rect.setTranslateX((temp.rect.getTranslateX())+move);
		temp.light.setTranslateX(temp.light.getTranslateX()+move);
		
		
		 if((x>temp.x2))
		{
			 temp.back = true;;							 
			 
		}
		else if(x<temp.x1)
		{
			temp.back = false;
		
		}
	
		 
		 
		
		 
	}
		
	public static void checkdown()
	{
		if(!booly)
		{
			xx=0;
			booly=true;
			timer3.play();					
		}
	}
	
	private void movewindow(int dist)
	{
		window.setTranslateX(window.getTranslateX()-dist);
		root2.setTranslateX(root2.getTranslateX()-dist);
		pos2+=dist;
	}
	
}



class evil
{
	
	int speed; 
	int x1;
	int x2;
	int y;
	boolean back;
	boolean status;
	Rectangle rect;
	Polygon light ;
	
	
	evil(int x1,int x2,int y,int speed)
	{
		this.speed = speed; 
		this.x1 = x1;
		this.x2 = x2;
		this.y = y;
		this.back = false;
		this.status = true;
		setupevil();
	}

	private void setupevil() 
	{
		this.rect = new Rectangle();
		this.rect.setWidth(50);
		this.rect.setHeight(10);
		this.rect.setTranslateX(x1);
		this.rect.setTranslateY(y);
		System.out.println("x-> "+x1+"  y->"+y);
		setlight();
		Main.root2.getChildren().add(rect);	
	}
	
	private void setlight()
	{
		light  = new Polygon();  //(x1,y,x2,y,x1-Main.range,y+100,x2+Main.range,y+100);
		light.getPoints().addAll(new Double[] {
				(double)x1+5,									(double)y,
				(double)(x1+rect.getWidth())-5,				(double)y,
				(double)(x1+Main.range+rect.getWidth()),	500.0,
				(double)(x1-Main.range),					500.0	});
		
		light.setFill(Paint.valueOf(Color.GRAY.toString()));
		Main.root2.getChildren().add(light);
	}
	
	
}








class block
{
	static int width = 200;
	static int lastheight = 150;
	static int b_diff = 35;
	static int max = Main.windowheight - b_diff;
	static int[] arr = {1,2,-1,-2,-3};
	
	public static void add()
	{	
		Rectangle temp = new Rectangle();
		int height = height();
		temp.setHeight(height);
		System.out.println("height "+height);
		temp.setWidth(width);
		Main.heights.add((int) ( Main.window.getTranslateY()+(Main.windowheight-height-1) ) );
		Main.window.getChildren().add(temp);	
	}
	
	private static int height()
	{
		int height;
		do
		{
			int x = (int)((Math.random()-0.01)*5.0);
			System.out.println("                                "+x);
			
			height = lastheight+arr[x]*b_diff;
			
		}
		while( (  height > Main.windowheight )   ||   (height<0)    );
		
		lastheight = height;
		return height;
		
	}
	
	private static int height2()
	{
		int height = 0;
		while(true)
		{
			height =  (int)(Math.random()*max);
			if(height>lastheight)
			{
				if((height-lastheight<2*b_diff)& (height-lastheight>=b_diff) )
				{
					if(height<max)
					{
						break;						
					}
				}
			}
			
			else
			{
				if(	  (	  (lastheight-height) >=  b_diff	)   &  (height>b_diff)	)
				{
					//System.out.println("lastheight->   "+lastheight +"  height-> "+height+"  "+"last-hei->  "+(lastheight-height)+"   "+b_diff);
					break;
				}
			}
		}
		//System.out.println("---------"+height+"----------");
		lastheight = height;
		return height;
		
	}
	
		
}




























//			if((pos*block.width+pos2 > 10+attackrect.localToParent(0,0).getX()  )&(pos*block.width+pos2<attackrect.localToParent(0,0).getX()-10 ))


























