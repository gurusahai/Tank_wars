module com.example.tankwar {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.tankwar to javafx.fxml;
    exports com.example.tankwar;
}